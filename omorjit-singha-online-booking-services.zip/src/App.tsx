/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { AboutUs } from './components/AboutUs';
import { WhyChooseUs } from './components/WhyChooseUs';
import { BookingFormSection } from './components/BookingFormSection';
import { CustomerManagement } from './components/CustomerManagement';
import { Footer } from './components/Footer';
import { FloatingCallButton } from './components/FloatingCallButton';
import { CustomerRecord, BookingService } from './types/customer';
import {
  getStoredCustomers,
  saveCustomers,
  resetToSampleCustomers,
} from './utils/customerStorage';
import { CheckCircle2 } from 'lucide-react';

export default function App() {
  const [customers, setCustomers] = useState<CustomerRecord[]>([]);
  const [activeSection, setActiveSection] = useState<string>('home');
  const [preselectedService, setPreselectedService] = useState<BookingService | undefined>(undefined);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Load records from browser storage on mount
  useEffect(() => {
    const loaded = getStoredCustomers();
    setCustomers(loaded);
  }, []);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  const handleAddCustomer = (newCustomer: CustomerRecord) => {
    const updated = [newCustomer, ...customers];
    setCustomers(updated);
    saveCustomers(updated);
    showToast(`Customer "${newCustomer.fullName}" saved to browser storage.`);
  };

  const handleUpdateCustomer = (updatedRecord: CustomerRecord) => {
    const updated = customers.map((c) => (c.id === updatedRecord.id ? updatedRecord : c));
    setCustomers(updated);
    saveCustomers(updated);
    showToast(`Record for "${updatedRecord.fullName}" updated.`);
  };

  const handleDeleteCustomer = (id: string) => {
    const target = customers.find((c) => c.id === id);
    const updated = customers.filter((c) => c.id !== id);
    setCustomers(updated);
    saveCustomers(updated);
    showToast(`Customer record ${target ? `"${target.fullName}"` : ''} deleted.`);
  };

  const handleResetSampleData = () => {
    const samples = resetToSampleCustomers();
    setCustomers(samples);
    showToast('Loaded sample customer records into browser storage.');
  };

  const scrollToSection = (sectionId: string) => {
    setActiveSection(sectionId);
    const el = document.getElementById(sectionId);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const handleSelectServiceFromCard = (serviceName: BookingService) => {
    setPreselectedService(serviceName);
    scrollToSection('booking');
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#2E2024] font-sans-clean flex flex-col selection:bg-[#E8C8BE] selection:text-[#541523]">
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-24 right-6 z-50 bg-[#4A101C] text-white px-5 py-3 rounded-2xl shadow-xl flex items-center gap-3 text-xs sm:text-sm animate-in fade-in slide-in-from-top-3 duration-200">
          <CheckCircle2 className="w-4 h-4 text-[#E8C8BE] shrink-0" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Navbar */}
      <Navbar
        activeSection={activeSection}
        onNavigate={scrollToSection}
        recordCount={customers.length}
      />

      {/* Main Content Sections */}
      <main className="flex-1">
        {/* Hero Section */}
        <Hero
          onBookNow={() => scrollToSection('booking')}
          onViewServices={() => scrollToSection('services')}
        />

        {/* Services Section */}
        <ServicesSection onSelectService={handleSelectServiceFromCard} />

        {/* About Us Section */}
        <AboutUs />

        {/* Why Choose Us Section */}
        <WhyChooseUs />

        {/* Booking Form Section with Real-Time Age Calculation */}
        <BookingFormSection
          selectedServicePreload={preselectedService}
          onCustomerAdded={handleAddCustomer}
          onGoToAdmin={() => scrollToSection('admin')}
        />

        {/* Customer Management (Admin Records Table) */}
        <CustomerManagement
          customers={customers}
          onAddCustomer={handleAddCustomer}
          onUpdateCustomer={handleUpdateCustomer}
          onDeleteCustomer={handleDeleteCustomer}
          onResetSampleData={handleResetSampleData}
        />
      </main>

      {/* Footer */}
      <Footer onNavigate={scrollToSection} />

      {/* Floating Direct Call Button */}
      <FloatingCallButton />
    </div>
  );
}

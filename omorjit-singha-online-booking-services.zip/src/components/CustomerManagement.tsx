import React, { useState, useMemo } from 'react';
import {
  Search,
  Plus,
  Edit2,
  Trash2,
  Phone,
  RotateCcw,
  CheckCircle2,
  AlertCircle,
  FileSpreadsheet,
} from 'lucide-react';
import { CustomerRecord, BookingStatus, STATUS_OPTIONS } from '../types/customer';
import { formatDateDisplay, exportCustomersToCSV } from '../utils/customerStorage';
import { CustomerModal } from './CustomerModal';

interface CustomerManagementProps {
  customers: CustomerRecord[];
  onAddCustomer: (customer: CustomerRecord) => void;
  onUpdateCustomer: (customer: CustomerRecord) => void;
  onDeleteCustomer: (id: string) => void;
  onResetSampleData: () => void;
}

export const CustomerManagement: React.FC<CustomerManagementProps> = ({
  customers,
  onAddCustomer,
  onUpdateCustomer,
  onDeleteCustomer,
  onResetSampleData,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | BookingStatus>('All');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingRecord, setEditingRecord] = useState<CustomerRecord | null>(null);
  const [deleteConfirmId, setDeleteConfirmId] = useState<string | null>(null);

  // Filtered customer records
  const filteredCustomers = useMemo(() => {
    return customers.filter((cust) => {
      const q = searchQuery.toLowerCase().trim();
      const matchesSearch =
        !q ||
        cust.fullName.toLowerCase().includes(q) ||
        cust.phoneNumber.toLowerCase().includes(q) ||
        cust.service.toLowerCase().includes(q) ||
        cust.status.toLowerCase().includes(q) ||
        (cust.notes && cust.notes.toLowerCase().includes(q));

      const matchesStatus = statusFilter === 'All' || cust.status === statusFilter;

      return matchesSearch && matchesStatus;
    });
  }, [customers, searchQuery, statusFilter]);

  // Counts
  const counts = useMemo(() => {
    return {
      all: customers.length,
      pending: customers.filter((c) => c.status === 'Pending').length,
      inProgress: customers.filter((c) => c.status === 'In Progress').length,
      completed: customers.filter((c) => c.status === 'Completed').length,
      cancelled: customers.filter((c) => c.status === 'Cancelled').length,
    };
  }, [customers]);

  const handleEditClick = (record: CustomerRecord) => {
    setEditingRecord(record);
    setIsModalOpen(true);
  };

  const handleAddClick = () => {
    setEditingRecord(null);
    setIsModalOpen(true);
  };

  const handleSaveModal = (record: CustomerRecord) => {
    if (editingRecord) {
      onUpdateCustomer(record);
    } else {
      onAddCustomer(record);
    }
  };

  const handleStatusQuickChange = (id: string, newStatus: BookingStatus) => {
    const target = customers.find((c) => c.id === id);
    if (target) {
      onUpdateCustomer({ ...target, status: newStatus, updatedAt: new Date().toISOString() });
    }
  };

  const getStatusBadgeStyle = (status: BookingStatus) => {
    switch (status) {
      case 'Completed':
        return 'bg-[#EBF5EA] text-[#245C2C] border-[#CCE4C9]';
      case 'In Progress':
        return 'bg-[#F2EDF8] text-[#55276D] border-[#DDD0E9]';
      case 'Pending':
        return 'bg-[#FDF2E7] text-[#8C4A19] border-[#F1D7BE]';
      case 'Cancelled':
        return 'bg-[#FCECEE] text-[#8C1E2B] border-[#F4CCD1]';
      default:
        return 'bg-neutral-100 text-neutral-800 border-neutral-200';
    }
  };

  return (
    <section id="admin" className="py-16 md:py-24 bg-[#F5EEE6]/50 border-t border-[#E9DED4]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Top Header & Add Button */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
          <div>
            <h2 className="font-serif-brand text-3xl sm:text-4xl font-semibold text-[#4A101C] tracking-tight">
              Customer Management
            </h2>
            <p className="text-sm text-[#5F4A50] mt-1">
              Browse, filter, edit customer applications and keep browser storage synced.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5">
            <button
              onClick={() => exportCustomersToCSV(customers)}
              className="px-4 py-2 rounded-xl bg-white hover:bg-[#FAF7F2] border border-[#DAC7BE] text-[#4A101C] text-xs sm:text-sm font-medium transition-colors flex items-center gap-1.5 cursor-pointer shadow-2xs"
              title="Download customer list as CSV spreadsheet"
            >
              <FileSpreadsheet className="w-4 h-4 text-[#7E2238]" />
              <span className="hidden sm:inline">Export CSV</span>
            </button>

            <button
              onClick={handleAddClick}
              className="px-4 sm:px-5 py-2.5 rounded-xl bg-[#7E2238] hover:bg-[#681628] text-white text-xs sm:text-sm font-semibold transition-all duration-200 flex items-center gap-2 cursor-pointer shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span>Add Customer</span>
            </button>
          </div>
        </div>

        {/* Stats bar */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-4 mb-6">
          <button
            onClick={() => setStatusFilter('All')}
            className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
              statusFilter === 'All'
                ? 'bg-white border-[#7E2238] shadow-sm ring-1 ring-[#7E2238]'
                : 'bg-[#FAF7F2] border-[#E5D8CE] hover:bg-white'
            }`}
          >
            <div className="text-xs font-semibold text-[#6E575D] uppercase tracking-wider">Total Records</div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-[#4A101C] mt-0.5 tabular-nums">
              {counts.all}
            </div>
          </button>

          <button
            onClick={() => setStatusFilter('Pending')}
            className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
              statusFilter === 'Pending'
                ? 'bg-white border-[#8C4A19] shadow-sm ring-1 ring-[#8C4A19]'
                : 'bg-[#FAF7F2] border-[#E5D8CE] hover:bg-white'
            }`}
          >
            <div className="text-xs font-semibold text-[#8C4A19] uppercase tracking-wider">Pending</div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-[#8C4A19] mt-0.5 tabular-nums">
              {counts.pending}
            </div>
          </button>

          <button
            onClick={() => setStatusFilter('In Progress')}
            className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
              statusFilter === 'In Progress'
                ? 'bg-white border-[#55276D] shadow-sm ring-1 ring-[#55276D]'
                : 'bg-[#FAF7F2] border-[#E5D8CE] hover:bg-white'
            }`}
          >
            <div className="text-xs font-semibold text-[#55276D] uppercase tracking-wider">In Progress</div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-[#55276D] mt-0.5 tabular-nums">
              {counts.inProgress}
            </div>
          </button>

          <button
            onClick={() => setStatusFilter('Completed')}
            className={`p-3.5 rounded-2xl border text-left transition-all cursor-pointer ${
              statusFilter === 'Completed'
                ? 'bg-white border-[#245C2C] shadow-sm ring-1 ring-[#245C2C]'
                : 'bg-[#FAF7F2] border-[#E5D8CE] hover:bg-white'
            }`}
          >
            <div className="text-xs font-semibold text-[#245C2C] uppercase tracking-wider">Completed</div>
            <div className="text-xl sm:text-2xl font-bold font-serif text-[#245C2C] mt-0.5 tabular-nums">
              {counts.completed}
            </div>
          </button>
        </div>

        {/* Search Bar - Exactly like Screenshot 2 with Burgundy palette */}
        <div className="mb-6">
          <div className="relative max-w-md">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-4 h-4 text-[#8C747B]" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, phone or service..."
              className="w-full pl-11 pr-4 py-3 rounded-full bg-white border border-[#DAC7BE] text-[#4A101C] placeholder-[#9E8A90] text-sm focus:outline-none focus:ring-2 focus:ring-[#B04A5A] focus:border-transparent transition-all shadow-2xs"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery('')}
                className="absolute right-3.5 top-1/2 -translate-y-1/2 text-xs text-[#8C747B] hover:text-[#4A101C] cursor-pointer"
              >
                Clear
              </button>
            )}
          </div>
        </div>

        {/* Customer Records Table Container */}
        <div className="bg-[#FAF7F2] rounded-3xl border border-[#E5D8CE] shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="border-b border-[#E8DDD4] bg-[#F5ECE5]/60">
                  <th className="py-4 px-6 text-[11px] sm:text-xs font-bold uppercase tracking-[0.16em] text-[#5E474D]">
                    NAME
                  </th>
                  <th className="py-4 px-6 text-[11px] sm:text-xs font-bold uppercase tracking-[0.16em] text-[#5E474D]">
                    PHONE
                  </th>
                  <th className="py-4 px-6 text-[11px] sm:text-xs font-bold uppercase tracking-[0.16em] text-[#5E474D]">
                    DOB / AGE
                  </th>
                  <th className="py-4 px-6 text-[11px] sm:text-xs font-bold uppercase tracking-[0.16em] text-[#5E474D]">
                    SERVICE
                  </th>
                  <th className="py-4 px-6 text-[11px] sm:text-xs font-bold uppercase tracking-[0.16em] text-[#5E474D]">
                    STATUS
                  </th>
                  <th className="py-4 px-6 text-[11px] sm:text-xs font-bold uppercase tracking-[0.16em] text-[#5E474D] text-right">
                    ACTIONS
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#EDE2D9]">
                {filteredCustomers.length === 0 ? (
                  <tr>
                    <td colSpan={6} className="py-16 text-center text-[#7E696F] text-sm">
                      <div className="flex flex-col items-center justify-center space-y-2">
                        <AlertCircle className="w-6 h-6 text-[#A59096]" />
                        <span className="font-medium text-base text-[#4A101C]">No customer records found.</span>
                        <p className="text-xs text-[#806B71] max-w-sm">
                          {searchQuery || statusFilter !== 'All'
                            ? 'Try clearing your search query or status filter.'
                            : 'Submit a new booking above or click Add Customer to create a record.'}
                        </p>
                        {customers.length === 0 && (
                          <button
                            onClick={onResetSampleData}
                            className="mt-3 px-4 py-2 rounded-xl bg-white border border-[#DAC7BE] text-xs font-semibold text-[#7E2238] hover:bg-[#F6ECE7] transition-colors"
                          >
                            Load Sample Customer Data
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                ) : (
                  filteredCustomers.map((cust) => (
                    <tr
                      key={cust.id}
                      className="hover:bg-white/80 transition-colors group text-sm text-[#38262B]"
                    >
                      {/* Name & ID */}
                      <td className="py-4 px-6 whitespace-nowrap">
                        <div className="font-semibold text-[#4A101C]">{cust.fullName}</div>
                        <div className="text-[11px] text-[#8A757B] font-mono">{cust.id}</div>
                      </td>

                      {/* Phone */}
                      <td className="py-4 px-6 whitespace-nowrap">
                        <a
                          href={`tel:${cust.phoneNumber.replace(/\s+/g, '')}`}
                          className="inline-flex items-center gap-1.5 text-[#7E2238] hover:underline font-medium"
                          title="Call customer"
                        >
                          <Phone className="w-3.5 h-3.5 text-[#8C2D43]" />
                          <span>{cust.phoneNumber}</span>
                        </a>
                      </td>

                      {/* DOB / Age */}
                      <td className="py-4 px-6 whitespace-nowrap">
                        <div className="text-[#3E292E] font-medium">
                          {formatDateDisplay(cust.dateOfBirth)}
                        </div>
                        <div className="text-xs text-[#7B666C] tabular-nums">
                          Age: <span className="font-semibold text-[#4A101C]">{cust.age}</span> yrs
                        </div>
                      </td>

                      {/* Service */}
                      <td className="py-4 px-6">
                        <div className="max-w-xs font-medium text-[#38262B] truncate" title={cust.service}>
                          {cust.service}
                        </div>
                        {cust.notes && (
                          <div className="text-xs text-[#806B71] truncate max-w-xs" title={cust.notes}>
                            Note: {cust.notes}
                          </div>
                        )}
                      </td>

                      {/* Status Dropdown */}
                      <td className="py-4 px-6 whitespace-nowrap">
                        <div className="relative inline-block">
                          <select
                            value={cust.status}
                            onChange={(e) =>
                              handleStatusQuickChange(cust.id, e.target.value as BookingStatus)
                            }
                            className={`text-xs font-semibold px-2.5 py-1 rounded-full border cursor-pointer focus:outline-none focus:ring-1 focus:ring-[#B04A5A] appearance-none pr-5 ${getStatusBadgeStyle(
                              cust.status
                            )}`}
                          >
                            {STATUS_OPTIONS.map((st) => (
                              <option key={st} value={st}>
                                {st}
                              </option>
                            ))}
                          </select>
                          <span className="pointer-events-none absolute right-1.5 top-1/2 -translate-y-1/2 text-[9px] opacity-70">
                            ▼
                          </span>
                        </div>
                      </td>

                      {/* Actions */}
                      <td className="py-4 px-6 whitespace-nowrap text-right">
                        <div className="flex items-center justify-end gap-2">
                          <button
                            onClick={() => handleEditClick(cust)}
                            className="p-1.5 rounded-lg text-[#6E4E55] hover:text-[#4A101C] hover:bg-[#F6EAE7] transition-colors cursor-pointer"
                            title="Edit customer details"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => setDeleteConfirmId(cust.id)}
                            className="p-1.5 rounded-lg text-[#94313B] hover:text-[#741B23] hover:bg-[#FCECEE] transition-colors cursor-pointer"
                            title="Delete customer record"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>

          {/* Table Footer info */}
          <div className="py-3.5 px-6 border-t border-[#E8DDD4] bg-[#F7EFE8] flex flex-col sm:flex-row items-center justify-between text-xs text-[#7B666C] gap-2">
            <div>
              Showing <span className="font-semibold text-[#4A101C]">{filteredCustomers.length}</span> of{' '}
              <span className="font-semibold text-[#4A101C]">{customers.length}</span> saved customer records
            </div>
            <div className="flex items-center gap-4">
              <span className="flex items-center gap-1.5 text-[#5A3F45]">
                <CheckCircle2 className="w-3.5 h-3.5 text-[#7E2238]" />
                Saved locally in browser storage
              </span>
              <button
                onClick={onResetSampleData}
                className="hover:text-[#4A101C] underline cursor-pointer flex items-center gap-1"
                title="Reset records to default sample data"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset Samples</span>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Add / Edit Modal */}
      <CustomerModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onSave={handleSaveModal}
        initialRecord={editingRecord}
      />

      {/* Delete Confirmation Modal */}
      {deleteConfirmId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-xs animate-in fade-in duration-150">
          <div className="bg-[#FAF7F2] rounded-3xl max-w-sm w-full p-6 border border-[#E5D8CE] shadow-xl text-center space-y-4">
            <div className="w-12 h-12 rounded-full bg-rose-100 text-rose-800 flex items-center justify-center mx-auto">
              <Trash2 className="w-6 h-6" />
            </div>
            <div>
              <h4 className="font-serif-brand text-xl font-semibold text-[#4A101C]">Delete Customer?</h4>
              <p className="text-xs text-[#6E575D] mt-1.5">
                Are you sure you want to delete this customer record? This action will remove it from browser storage.
              </p>
            </div>
            <div className="flex items-center justify-center gap-3 pt-2">
              <button
                onClick={() => setDeleteConfirmId(null)}
                className="px-4 py-2 rounded-xl border border-[#DAC7BE] text-xs font-semibold text-[#5E474D] hover:bg-[#F5EDE5]"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  onDeleteCustomer(deleteConfirmId);
                  setDeleteConfirmId(null);
                }}
                className="px-4 py-2 rounded-xl bg-[#7E2238] hover:bg-[#681628] text-white text-xs font-semibold shadow-xs"
              >
                Yes, Delete
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

import React, { useState } from 'react';
import { Phone, Copy, Check, ExternalLink } from 'lucide-react';
import { SUPPORT_PHONE_DISPLAY, SUPPORT_PHONE_TEL } from '../utils/customerStorage';

export const FloatingCallButton: React.FC = () => {
  const [showTooltip, setShowTooltip] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleCopy = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    navigator.clipboard.writeText('+917099626706');
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col items-end">
      {/* Quick Action Flyout */}
      {showTooltip && (
        <div className="mb-3 bg-white/95 backdrop-blur-md rounded-2xl p-4 shadow-xl border border-[#E5D8CE] text-[#4A101C] text-xs sm:text-sm w-64 animate-in fade-in slide-in-from-bottom-3 duration-200">
          <div className="font-semibold text-sm text-[#4A101C] mb-1">
            Omorjit Singha Support
          </div>
          <p className="text-xs text-[#7B666C] mb-3">
            Direct assistance for railway tatkal, flights, passports, and official documentation.
          </p>

          <div className="flex items-center justify-between bg-[#F8F1EA] rounded-xl px-3 py-2 mb-3">
            <span className="font-mono font-bold text-xs sm:text-sm text-[#4A101C]">
              {SUPPORT_PHONE_DISPLAY}
            </span>
            <button
              onClick={handleCopy}
              className="p-1 text-[#7E2238] hover:text-[#541523] transition-colors cursor-pointer"
              title="Copy phone number"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <a
              href={SUPPORT_PHONE_TEL}
              className="flex items-center justify-center gap-1.5 bg-[#7E2238] hover:bg-[#681628] text-white py-2 px-3 rounded-xl text-xs font-semibold shadow-xs transition-colors"
            >
              <Phone className="w-3.5 h-3.5 fill-white text-white" />
              <span>Call Now</span>
            </a>
            <a
              href="https://wa.me/917099626706"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-1.5 bg-[#F5ECE5] hover:bg-[#EAE0D7] text-[#4A101C] py-2 px-3 rounded-xl text-xs font-semibold transition-colors"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>WhatsApp</span>
            </a>
          </div>
        </div>
      )}

      {/* Floating Call Button with Warm Burgundy & Cream palette */}
      <div className="relative group">
        <a
          href={SUPPORT_PHONE_TEL}
          onMouseEnter={() => setShowTooltip(true)}
          className="w-14 h-14 sm:w-16 sm:h-16 rounded-full bg-[#7E2238] hover:bg-[#681628] active:scale-95 text-white flex items-center justify-center shadow-lg hover:shadow-xl transition-all duration-300 cursor-pointer focus:outline-none focus:ring-4 focus:ring-[#D8A6B0]"
          aria-label="Direct phone call to Omorjit Singha Online Booking Services"
          title={`Call ${SUPPORT_PHONE_DISPLAY}`}
        >
          <Phone className="w-6 h-6 sm:w-7 sm:h-7 fill-white text-white" />
        </a>

        {/* Pulse ring for call attention */}
        <span className="absolute -inset-1 rounded-full bg-[#7E2238]/30 animate-ping pointer-events-none -z-10" />
      </div>
    </div>
  );
};

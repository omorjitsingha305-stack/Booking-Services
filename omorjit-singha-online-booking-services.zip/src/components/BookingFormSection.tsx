import React, { useState, useEffect } from 'react';
import { Clock, ShieldCheck, CheckCircle2, Phone, ArrowRight } from 'lucide-react';
import { BookingService, CustomerRecord, AVAILABLE_SERVICES } from '../types/customer';
import { calculateAge, SUPPORT_PHONE_DISPLAY, SUPPORT_PHONE_TEL } from '../utils/customerStorage';

interface BookingFormSectionProps {
  selectedServicePreload?: BookingService;
  onCustomerAdded: (customer: CustomerRecord) => void;
  onGoToAdmin: () => void;
}

export const BookingFormSection: React.FC<BookingFormSectionProps> = ({
  selectedServicePreload,
  onCustomerAdded,
  onGoToAdmin,
}) => {
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [service, setService] = useState<BookingService>(
    selectedServicePreload || 'Railway Booking (AC / Non-AC / Tatkal)'
  );
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [age, setAge] = useState<number | null>(null);
  const [notes, setNotes] = useState('');

  const [submittedRecord, setSubmittedRecord] = useState<CustomerRecord | null>(null);
  const [errorMsg, setErrorMsg] = useState('');

  // Update service when preload changes
  useEffect(() => {
    if (selectedServicePreload) {
      setService(selectedServicePreload);
    }
  }, [selectedServicePreload]);

  // Real-time automatic age calculation from DOB
  useEffect(() => {
    if (dateOfBirth) {
      const computed = calculateAge(dateOfBirth);
      setAge(computed);
    } else {
      setAge(null);
    }
  }, [dateOfBirth]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');

    if (!fullName.trim()) {
      setErrorMsg('Please enter your full name.');
      return;
    }
    if (!phoneNumber.trim()) {
      setErrorMsg('Please enter your phone number.');
      return;
    }
    if (!dateOfBirth) {
      setErrorMsg('Please select your Date of Birth.');
      return;
    }

    const calculatedAge = calculateAge(dateOfBirth) ?? 0;

    const newRecord: CustomerRecord = {
      id: `REC-${Date.now().toString().slice(-6)}`,
      fullName: fullName.trim(),
      phoneNumber: phoneNumber.trim(),
      dateOfBirth,
      age: calculatedAge,
      service,
      status: 'Pending',
      notes: notes.trim(),
      createdAt: new Date().toISOString(),
    };

    onCustomerAdded(newRecord);
    setSubmittedRecord(newRecord);

    // Reset fields
    setFullName('');
    setPhoneNumber('');
    setDateOfBirth('');
    setAge(null);
    setNotes('');
  };

  return (
    <section id="booking" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          {/* Left Column: Copy & Trust Signals */}
          <div className="lg:col-span-5 space-y-6 sm:space-y-8">
            <div className="flex items-center gap-3">
              <span className="w-8 h-[1.5px] bg-[#9D384E]"></span>
              <span className="text-[12px] sm:text-[13px] font-bold uppercase tracking-[0.2em] text-[#8C2D43]">
                BOOK A SERVICE
              </span>
            </div>

            <h2 className="font-serif-brand text-4xl sm:text-5xl lg:text-[54px] font-semibold text-[#4A101C] leading-[1.12] tracking-tight">
              Submit your details easily.
            </h2>

            <p className="text-base sm:text-lg text-[#5F4A50] leading-relaxed font-normal">
              Select the service you need and provide your information. We will record your
              request securely and contact you promptly with the next steps.
            </p>

            <div className="flex flex-wrap items-center gap-6 pt-2">
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold tracking-wider text-[#7E2238] uppercase">
                <Clock className="w-4 h-4 text-[#7E2238]" />
                <span>FAST RESPONSE</span>
              </div>
              <div className="flex items-center gap-2.5 text-xs sm:text-sm font-semibold tracking-wider text-[#7E2238] uppercase">
                <ShieldCheck className="w-4 h-4 text-[#7E2238]" />
                <span>SECURE DATA</span>
              </div>
            </div>

            <div className="p-5 rounded-2xl bg-[#F5EDE5] border border-[#E6D9CF] space-y-2 text-xs sm:text-sm text-[#541523]">
              <div className="font-semibold text-[#4A101C] flex items-center gap-2">
                <Phone className="w-4 h-4 text-[#7E2238]" />
                <span>Prefer to book over call?</span>
              </div>
              <p className="text-[#5F4A50]">
                Call Omorjit Singha directly at{' '}
                <a
                  href={SUPPORT_PHONE_TEL}
                  className="font-semibold text-[#7E2238] underline hover:text-[#541523]"
                >
                  {SUPPORT_PHONE_DISPLAY}
                </a>{' '}
                for instant assistance with Tatkal tickets, flight seat reservation, or urgent passport renewal.
              </p>
            </div>
          </div>

          {/* Right Column: Form Card */}
          <div className="lg:col-span-7">
            <div className="bg-[#FAF7F2] rounded-[32px] sm:rounded-[40px] p-6 sm:p-10 border border-[#E5D8CE] shadow-sm relative">
              {submittedRecord ? (
                <div className="text-center py-8 space-y-5 animate-in fade-in zoom-in-95 duration-200">
                  <div className="w-16 h-16 rounded-full bg-[#F6EAE7] text-[#7E2238] flex items-center justify-center mx-auto">
                    <CheckCircle2 className="w-9 h-9" />
                  </div>
                  <div>
                    <h3 className="font-serif-brand text-2xl sm:text-3xl font-semibold text-[#4A101C]">
                      Booking Request Recorded!
                    </h3>
                    <p className="text-sm text-[#5F4A50] mt-2 max-w-md mx-auto">
                      Thank you, <span className="font-semibold text-[#4A101C]">{submittedRecord.fullName}</span>.
                      Your request for <span className="font-semibold text-[#4A101C]">{submittedRecord.service}</span> has been securely saved in the system.
                    </p>
                  </div>

                  <div className="bg-[#F5ECE5] rounded-2xl p-4 max-w-md mx-auto text-left text-xs sm:text-sm space-y-2 text-[#4A101C]">
                    <div className="flex justify-between border-b border-[#E6D9CF] pb-1.5">
                      <span className="text-[#7D666C]">Booking Reference:</span>
                      <span className="font-mono font-bold text-[#4A101C]">{submittedRecord.id}</span>
                    </div>
                    <div className="flex justify-between border-b border-[#E6D9CF] pb-1.5">
                      <span className="text-[#7D666C]">Phone Number:</span>
                      <span className="font-medium text-[#4A101C]">{submittedRecord.phoneNumber}</span>
                    </div>
                    <div className="flex justify-between border-b border-[#E6D9CF] pb-1.5">
                      <span className="text-[#7D666C]">Age (Auto-calculated):</span>
                      <span className="font-medium text-[#4A101C]">{submittedRecord.age} years</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-[#7D666C]">Initial Status:</span>
                      <span className="bg-[#F6EAE7] text-[#7E2238] px-2 py-0.5 rounded-full font-semibold text-xs border border-[#E9D1C9]">
                        {submittedRecord.status}
                      </span>
                    </div>
                  </div>

                  <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-4">
                    <button
                      onClick={() => setSubmittedRecord(null)}
                      className="w-full sm:w-auto px-6 py-2.5 rounded-full border border-[#DAC6BE] bg-white text-[#4A101C] text-sm font-medium hover:bg-[#F7EFEA] cursor-pointer"
                    >
                      Submit Another Request
                    </button>
                    <button
                      onClick={onGoToAdmin}
                      className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-[#7E2238] hover:bg-[#681628] text-white text-sm font-medium transition-all cursor-pointer flex items-center justify-center gap-2"
                    >
                      <span>View in Customer Records</span>
                      <ArrowRight className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-5">
                  {errorMsg && (
                    <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs sm:text-sm font-medium">
                      {errorMsg}
                    </div>
                  )}

                  {/* Full Name */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] sm:text-xs font-bold tracking-[0.16em] uppercase text-[#5E474D]">
                      FULL NAME
                    </label>
                    <input
                      type="text"
                      required
                      value={fullName}
                      onChange={(e) => setFullName(e.target.value)}
                      placeholder="Your full name"
                      className="w-full px-5 py-3.5 rounded-2xl bg-white border border-[#DAC7BE] text-[#4A101C] placeholder-[#9E8A90] text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-[#B04A5A] focus:border-transparent transition-all"
                    />
                  </div>

                  {/* Phone Number */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] sm:text-xs font-bold tracking-[0.16em] uppercase text-[#5E474D]">
                      PHONE NUMBER
                    </label>
                    <input
                      type="tel"
                      required
                      value={phoneNumber}
                      onChange={(e) => setPhoneNumber(e.target.value)}
                      placeholder="Your phone number"
                      className="w-full px-5 py-3.5 rounded-2xl bg-white border border-[#DAC7BE] text-[#4A101C] placeholder-[#9E8A90] text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-[#B04A5A] focus:border-transparent transition-all"
                    />
                  </div>

                  {/* Service Required */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] sm:text-xs font-bold tracking-[0.16em] uppercase text-[#5E474D]">
                      SERVICE REQUIRED
                    </label>
                    <div className="relative">
                      <select
                        value={service}
                        onChange={(e) => setService(e.target.value as BookingService)}
                        className="w-full px-5 py-3.5 rounded-2xl bg-white border border-[#DAC7BE] text-[#4A101C] text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-[#B04A5A] focus:border-transparent appearance-none cursor-pointer transition-all pr-10"
                      >
                        {AVAILABLE_SERVICES.map((s) => (
                          <option key={s} value={s}>
                            {s}
                          </option>
                        ))}
                      </select>
                      <div className="pointer-events-none absolute inset-y-0 right-0 flex items-center px-4 text-[#7A6369]">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                        </svg>
                      </div>
                    </div>
                  </div>

                  {/* DOB and Age row */}
                  <div className="grid grid-cols-1 sm:grid-cols-12 gap-4">
                    {/* Date of Birth */}
                    <div className="sm:col-span-7 space-y-1.5">
                      <label className="block text-[11px] sm:text-xs font-bold tracking-[0.16em] uppercase text-[#5E474D]">
                        DATE OF BIRTH
                      </label>
                      <div className="relative">
                        <input
                          type="date"
                          required
                          max={new Date().toISOString().split('T')[0]}
                          value={dateOfBirth}
                          onChange={(e) => setDateOfBirth(e.target.value)}
                          className="w-full px-5 py-3.5 rounded-2xl bg-white border border-[#DAC7BE] text-[#4A101C] text-sm sm:text-base focus:outline-none focus:ring-2 focus:ring-[#B04A5A] focus:border-transparent transition-all"
                        />
                      </div>
                    </div>

                    {/* Age (Auto-calculated) */}
                    <div className="sm:col-span-5 space-y-1.5">
                      <label className="block text-[11px] sm:text-xs font-bold tracking-[0.16em] uppercase text-[#5E474D]">
                        AGE (AUTO-CALCULATED)
                      </label>
                      <input
                        type="text"
                        readOnly
                        value={age !== null ? `${age} years` : ''}
                        placeholder="Auto-calculated"
                        className="w-full px-5 py-3.5 rounded-2xl bg-[#ECE2DA] border border-[#DAC7BE] text-[#4A101C] font-semibold text-sm sm:text-base cursor-not-allowed select-none transition-all placeholder-[#9E8A90]"
                      />
                    </div>
                  </div>

                  {/* Optional Notes / Details */}
                  <div className="space-y-1.5">
                    <label className="block text-[11px] sm:text-xs font-bold tracking-[0.16em] uppercase text-[#5E474D]">
                      ADDITIONAL NOTES / JOURNEY DETAILS (OPTIONAL)
                    </label>
                    <textarea
                      rows={2}
                      value={notes}
                      onChange={(e) => setNotes(e.target.value)}
                      placeholder="e.g. Journey date, Tatkal train preference, passport renewal reason, or job post name"
                      className="w-full px-5 py-3 rounded-2xl bg-white border border-[#DAC7BE] text-[#4A101C] placeholder-[#9E8A90] text-sm focus:outline-none focus:ring-2 focus:ring-[#B04A5A] focus:border-transparent transition-all resize-none"
                    ></textarea>
                  </div>

                  {/* Submit Button */}
                  <div className="pt-2">
                    <button
                      type="submit"
                      className="w-full py-4 px-6 rounded-2xl bg-[#7E2238] hover:bg-[#681628] text-white font-semibold text-base transition-all duration-200 shadow-sm hover:shadow cursor-pointer flex items-center justify-center gap-2"
                    >
                      <span>Submit Request</span>
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

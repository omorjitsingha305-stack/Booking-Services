import React from 'react';
import { Plane, Globe, FileText, ArrowRight, Train, Bus, ShieldCheck, Briefcase } from 'lucide-react';
import transportImg from '../assets/images/service_transport_hub_1791215082382.jpg';
import passportImg from '../assets/images/service_traveler_passport_1791215097000.jpg';
import licenseImg from '../assets/images/service_license_form_1791215136357.jpg';
import { BookingService } from '../types/customer';

interface ServicesSectionProps {
  onSelectService: (service: BookingService) => void;
}

export const ServicesSection: React.FC<ServicesSectionProps> = ({ onSelectService }) => {
  return (
    <section id="services" className="py-20 md:py-28 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="flex items-center gap-3 mb-4">
          <span className="w-8 h-[1.5px] bg-[#9D384E]"></span>
          <span className="text-[12px] sm:text-[13px] font-bold uppercase tracking-[0.2em] text-[#8C2D43]">
            OUR SERVICES
          </span>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-12 items-end mb-14">
          <div className="lg:col-span-7">
            <h2 className="font-serif-brand text-3xl sm:text-4xl lg:text-[50px] font-semibold text-[#4A101C] leading-[1.15] tracking-tight">
              Comprehensive booking &amp; documentation.
            </h2>
          </div>
          <div className="lg:col-span-5">
            <p className="text-base sm:text-lg text-[#5F4A50] leading-relaxed">
              We provide expert assistance for all your travel and official documentation needs,
              ensuring accuracy and speed.
            </p>
          </div>
        </div>

        {/* 3 Service Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Card 1: Train, Bus & Flight Booking */}
          <div className="bg-[#FAF7F2] rounded-[32px] border border-[#E5D8CE] overflow-hidden flex flex-col transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
            <div className="p-4 pb-0">
              <div className="relative rounded-[24px] overflow-hidden aspect-[4/2.9] bg-[#EBE2DA]">
                <img
                  src={transportImg}
                  alt="Train, bus and flight ticketing assistance"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
            </div>

            <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#F6EAE7] text-[#7E2238] flex items-center justify-center mb-5">
                  <Plane className="w-5 h-5" />
                </div>

                <h3 className="font-serif-brand text-2xl font-semibold text-[#4A101C] mb-3">
                  Train, Bus &amp; Flight Booking
                </h3>

                <p className="text-sm text-[#5F4A50] leading-relaxed mb-5">
                  AC/Non-AC train tickets, Tatkal bookings, bus seats, and domestic/international flight reservations with seat selection and prompt PNR updates.
                </p>

                <div className="space-y-1.5 text-xs text-[#523E43] mb-6 pt-2 border-t border-[#EAE0D7]">
                  <div className="flex items-center gap-2">
                    <Train className="w-3.5 h-3.5 text-[#7E2238]" />
                    <span>Railway Booking (AC / Non-AC / Tatkal)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Plane className="w-3.5 h-3.5 text-[#7E2238]" />
                    <span>Domestic &amp; International Flights</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Bus className="w-3.5 h-3.5 text-[#7E2238]" />
                    <span>Intercity &amp; Sleeper Bus Bookings</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onSelectService('Railway Booking (AC / Non-AC / Tatkal)')}
                className="w-full py-2.5 px-4 rounded-xl border border-[#DFC9BF] bg-[#F7EFEA] hover:bg-[#7E2238] text-[#541523] hover:text-white font-medium text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Book Travel Service</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 2: Passport Services */}
          <div className="bg-[#FAF7F2] rounded-[32px] border border-[#E5D8CE] overflow-hidden flex flex-col transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
            <div className="p-4 pb-0">
              <div className="relative rounded-[24px] overflow-hidden aspect-[4/2.9] bg-[#EBE2DA]">
                <img
                  src={passportImg}
                  alt="Passport consultation and appointment scheduling"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
            </div>

            <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#F6EAE7] text-[#7E2238] flex items-center justify-center mb-5">
                  <Globe className="w-5 h-5" />
                </div>

                <h3 className="font-serif-brand text-2xl font-semibold text-[#4A101C] mb-3">
                  Passport Services
                </h3>

                <p className="text-sm text-[#5F4A50] leading-relaxed mb-5">
                  Complete guidance for new passport applications, document verification, renewal assistance, and fast PSK/POPSK appointment slot booking.
                </p>

                <div className="space-y-1.5 text-xs text-[#523E43] mb-6 pt-2 border-t border-[#EAE0D7]">
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#7E2238]" />
                    <span>Fresh Passport Online Application</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#7E2238]" />
                    <span>Passport Renewal &amp; Re-issue Support</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <ShieldCheck className="w-3.5 h-3.5 text-[#7E2238]" />
                    <span>Tatkaal &amp; Normal Slot Assistance</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onSelectService('Passport Services (New Application)')}
                className="w-full py-2.5 px-4 rounded-xl border border-[#DFC9BF] bg-[#F7EFEA] hover:bg-[#7E2238] text-[#541523] hover:text-white font-medium text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Book Passport Service</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Card 3: Licenses & Jobs */}
          <div className="bg-[#FAF7F2] rounded-[32px] border border-[#E5D8CE] overflow-hidden flex flex-col transition-all duration-300 hover:shadow-lg hover:-translate-y-1">
            <div className="p-4 pb-0">
              <div className="relative rounded-[24px] overflow-hidden aspect-[4/2.9] bg-[#EBE2DA]">
                <img
                  src={licenseImg}
                  alt="Documentation and government portal submission"
                  className="w-full h-full object-cover"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
            </div>

            <div className="p-6 sm:p-7 flex-1 flex flex-col justify-between">
              <div>
                <div className="w-10 h-10 rounded-xl bg-[#F6EAE7] text-[#7E2238] flex items-center justify-center mb-5">
                  <Briefcase className="w-5 h-5" />
                </div>

                <h3 className="font-serif-brand text-2xl font-semibold text-[#4A101C] mb-3">
                  Licenses &amp; Jobs
                </h3>

                <p className="text-sm text-[#5F4A50] leading-relaxed mb-5">
                  Expert form-filling and support for driving licenses, job applications, documentation, and official portal submissions without errors.
                </p>

                <div className="space-y-1.5 text-xs text-[#523E43] mb-6 pt-2 border-t border-[#EAE0D7]">
                  <div className="flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5 text-[#7E2238]" />
                    <span>Driving License (Learner &amp; Permanent)</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5 text-[#7E2238]" />
                    <span>Job Applications &amp; Recruitment Forms</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <FileText className="w-3.5 h-3.5 text-[#7E2238]" />
                    <span>Document Scanning &amp; Upload Compliance</span>
                  </div>
                </div>
              </div>

              <button
                onClick={() => onSelectService('Driving License Assistance')}
                className="w-full py-2.5 px-4 rounded-xl border border-[#DFC9BF] bg-[#F7EFEA] hover:bg-[#7E2238] text-[#541523] hover:text-white font-medium text-xs sm:text-sm transition-all duration-200 flex items-center justify-center gap-2 cursor-pointer"
              >
                <span>Book Documentation Help</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

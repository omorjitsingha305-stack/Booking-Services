import React from 'react';
import heroImg from '../assets/images/hero_booking_meeting_1791215051069.jpg';
import { ArrowRight, CheckCircle2 } from 'lucide-react';

interface HeroProps {
  onBookNow: () => void;
  onViewServices: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onBookNow, onViewServices }) => {
  return (
    <section id="home" className="relative pt-12 pb-20 md:py-24 overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-8 items-center">
          {/* Left Column: Copy & Actions */}
          <div className="lg:col-span-6 space-y-6 sm:space-y-8">
            <div className="flex items-center gap-3">
              <span className="w-8 h-[1.5px] bg-[#9D384E]"></span>
              <span className="text-[12px] sm:text-[13px] font-bold uppercase tracking-[0.2em] text-[#8C2D43]">
                PROFESSIONAL ASSISTANCE
              </span>
            </div>

            <h1 className="font-serif-brand text-4xl sm:text-5xl lg:text-[62px] font-semibold text-[#4A101C] leading-[1.12] tracking-tight">
              Expert Online Booking &amp; Services.
            </h1>

            <p className="text-base sm:text-lg text-[#5F4A50] leading-relaxed max-w-xl font-normal">
              From railway and flight tickets to passports, driving licenses, and job applications.
              We provide reliable, fast, and accurate documentation services.
            </p>

            <div className="flex flex-wrap items-center gap-4 pt-2">
              <button
                onClick={onViewServices}
                className="px-7 py-3 rounded-full border border-[#DAC6BE] bg-[#FAF7F2] hover:bg-white text-[#4A101C] font-medium text-sm transition-all duration-200 shadow-2xs hover:border-[#8C2D43] cursor-pointer"
              >
                View Services
              </button>
              <button
                onClick={onBookNow}
                className="px-7 py-3 rounded-full bg-[#7E2238] hover:bg-[#681628] text-white font-medium text-sm transition-all duration-200 shadow-sm hover:shadow cursor-pointer flex items-center gap-2"
              >
                <span>Book Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            <div className="pt-4 grid grid-cols-2 gap-4 text-xs sm:text-sm text-[#665056]">
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#7E2238]" />
                <span>Instant Confirmation &amp; Updates</span>
              </div>
              <div className="flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-[#7E2238]" />
                <span>Verified Official Submission</span>
              </div>
            </div>
          </div>

          {/* Right Column: Hero Arch Visual */}
          <div className="lg:col-span-6 flex justify-center lg:justify-end">
            <div className="relative w-full max-w-[490px]">
              {/* Outer decorative soft contour border */}
              <div className="absolute -inset-2.5 rounded-t-[190px] rounded-b-[36px] border border-[#DEC8C0]/80 pointer-events-none"></div>

              {/* Main Arch Frame */}
              <div className="relative rounded-t-[180px] rounded-b-[28px] overflow-hidden bg-[#ECE3DB] shadow-lg border border-[#D9C4BB]/70 aspect-[4/4.2]">
                <img
                  src={heroImg}
                  alt="Professional consultation and paperwork review"
                  className="w-full h-full object-cover object-center transform hover:scale-[1.02] transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="eager"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#4A101C]/25 via-transparent to-transparent pointer-events-none" />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

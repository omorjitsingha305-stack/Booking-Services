import React, { useState } from 'react';
import { Phone, Menu, X } from 'lucide-react';
import { SUPPORT_PHONE_DISPLAY, SUPPORT_PHONE_TEL } from '../utils/customerStorage';

interface NavbarProps {
  activeSection: string;
  onNavigate: (sectionId: string) => void;
  recordCount: number;
}

export const Navbar: React.FC<NavbarProps> = ({ activeSection, onNavigate, recordCount }) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleNavClick = (sectionId: string) => {
    setMobileMenuOpen(false);
    onNavigate(sectionId);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#FAF7F2]/90 backdrop-blur-md border-b border-[#EADED4] transition-all">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
        {/* Brand Zone */}
        <button
          onClick={() => handleNavClick('home')}
          className="text-left group cursor-pointer focus:outline-none"
        >
          <div className="font-serif-brand text-2xl sm:text-[26px] font-semibold text-[#541523] leading-tight group-hover:text-[#3F0E19] transition-colors">
            Omorjit Singha
          </div>
          <div className="text-[10px] sm:text-[11px] font-bold tracking-[0.22em] text-[#9E3E2F] uppercase mt-0.5">
            ONLINE BOOKING SERVICES
          </div>
        </button>

        {/* Desktop Nav Zone */}
        <nav className="hidden md:flex items-center gap-8 text-[15px] font-medium text-[#5E474D]">
          <button
            onClick={() => handleNavClick('home')}
            className={`transition-colors hover:text-[#541523] cursor-pointer ${
              activeSection === 'home' ? 'text-[#541523] font-semibold' : ''
            }`}
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('services')}
            className={`transition-colors hover:text-[#541523] cursor-pointer ${
              activeSection === 'services' ? 'text-[#541523] font-semibold' : ''
            }`}
          >
            Services
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className={`transition-colors hover:text-[#541523] cursor-pointer ${
              activeSection === 'about' ? 'text-[#541523] font-semibold' : ''
            }`}
          >
            About Us
          </button>
          <button
            onClick={() => handleNavClick('booking')}
            className={`transition-colors hover:text-[#541523] cursor-pointer ${
              activeSection === 'booking' ? 'text-[#541523] font-semibold' : ''
            }`}
          >
            Book Now
          </button>
          <button
            onClick={() => handleNavClick('contact')}
            className={`transition-colors hover:text-[#541523] cursor-pointer ${
              activeSection === 'contact' ? 'text-[#541523] font-semibold' : ''
            }`}
          >
            Contact
          </button>
          <button
            onClick={() => handleNavClick('admin')}
            className={`relative transition-colors hover:text-[#541523] cursor-pointer flex items-center gap-1.5 ${
              activeSection === 'admin' ? 'text-[#541523] font-semibold' : ''
            }`}
          >
            <span>Admin</span>
            {recordCount > 0 && (
              <span className="text-[11px] bg-[#F4E3DF] text-[#7E2238] font-bold px-1.5 py-0.2 rounded-full tabular-nums">
                {recordCount}
              </span>
            )}
          </button>
        </nav>

        {/* Action Zone: Call Now */}
        <div className="hidden sm:flex items-center gap-3">
          <a
            href={SUPPORT_PHONE_TEL}
            className="inline-flex items-center gap-2 bg-[#7E2238] hover:bg-[#681628] text-white font-medium text-sm px-5 py-2.5 rounded-full transition-all duration-200 shadow-sm hover:shadow"
            title={`Call directly: ${SUPPORT_PHONE_DISPLAY}`}
          >
            <Phone className="w-4 h-4 fill-white text-white" />
            <span className="whitespace-nowrap">Call Now</span>
          </a>
        </div>

        {/* Mobile Menu Button */}
        <div className="flex items-center gap-2 md:hidden">
          <a
            href={SUPPORT_PHONE_TEL}
            className="p-2 rounded-full bg-[#7E2238] text-white"
            aria-label="Call support"
          >
            <Phone className="w-4 h-4 fill-current" />
          </a>
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="p-2 rounded-lg text-[#541523] hover:bg-[#EFE8DF] focus:outline-none"
            aria-label="Toggle navigation menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="md:hidden bg-[#FAF7F2] border-b border-[#EADED4] px-4 pt-3 pb-6 space-y-3 animate-in fade-in slide-in-from-top-2 duration-200 shadow-lg">
          <button
            onClick={() => handleNavClick('home')}
            className="block w-full text-left px-3 py-2 rounded-lg text-base font-medium text-[#541523] hover:bg-[#F3ECE3]"
          >
            Home
          </button>
          <button
            onClick={() => handleNavClick('services')}
            className="block w-full text-left px-3 py-2 rounded-lg text-base font-medium text-[#541523] hover:bg-[#F3ECE3]"
          >
            Services
          </button>
          <button
            onClick={() => handleNavClick('about')}
            className="block w-full text-left px-3 py-2 rounded-lg text-base font-medium text-[#541523] hover:bg-[#F3ECE3]"
          >
            About Us
          </button>
          <button
            onClick={() => handleNavClick('booking')}
            className="block w-full text-left px-3 py-2 rounded-lg text-base font-medium text-[#541523] hover:bg-[#F3ECE3]"
          >
            Book a Service
          </button>
          <button
            onClick={() => handleNavClick('admin')}
            className="flex items-center justify-between w-full px-3 py-2 rounded-lg text-base font-medium text-[#541523] hover:bg-[#F3ECE3]"
          >
            <span>Customer Management (Admin)</span>
            <span className="text-xs bg-[#F4E3DF] text-[#7E2238] font-bold px-2 py-0.5 rounded-full tabular-nums">
              {recordCount} records
            </span>
          </button>
          <button
            onClick={() => handleNavClick('contact')}
            className="block w-full text-left px-3 py-2 rounded-lg text-base font-medium text-[#541523] hover:bg-[#F3ECE3]"
          >
            Contact
          </button>
          <div className="pt-2">
            <a
              href={SUPPORT_PHONE_TEL}
              className="flex items-center justify-center gap-2 w-full bg-[#7E2238] hover:bg-[#681628] text-white py-3 rounded-xl font-medium text-sm shadow-sm"
            >
              <Phone className="w-4 h-4 fill-white text-white" />
              <span>Call Direct: {SUPPORT_PHONE_DISPLAY}</span>
            </a>
          </div>
        </div>
      )}
    </header>
  );
};

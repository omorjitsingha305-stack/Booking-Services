import React from 'react';
import handshakeImg from '../assets/images/feature_business_handshake_1791215118911.jpg';

export const WhyChooseUs: React.FC = () => {
  return (
    <section className="py-20 bg-[#F5EEE6]/70 border-t border-[#E9DED4] relative overflow-hidden">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          {/* Left Column: Copy & 4 Feature Cards */}
          <div className="lg:col-span-7 space-y-6 sm:space-y-8">
            <div className="flex items-center gap-3">
              <span className="w-8 h-[1.5px] bg-[#9D384E]"></span>
              <span className="text-[12px] sm:text-[13px] font-bold uppercase tracking-[0.2em] text-[#8C2D43]">
                WHY CHOOSE US
              </span>
            </div>

            <h2 className="font-serif-brand text-3xl sm:text-4xl lg:text-[50px] font-semibold text-[#4A101C] leading-[1.18] tracking-tight">
              Seamless processing from start to finish.
            </h2>

            {/* 4 Feature Cards Grid */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-2">
              {/* Card 1 */}
              <div className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#E6D9CF] shadow-xs">
                <div className="flex items-center gap-3 mb-2.5">
                  <span className="w-3 h-3 rounded-full bg-[#7E2238] inline-block"></span>
                  <h3 className="font-semibold text-base text-[#4A101C]">Fast Processing</h3>
                </div>
                <p className="text-sm text-[#5F4A50] leading-relaxed">
                  We minimize wait times by handling the complex form structures efficiently.
                </p>
              </div>

              {/* Card 2 */}
              <div className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#E6D9CF] shadow-xs">
                <div className="flex items-center gap-3 mb-2.5">
                  <span className="w-3 h-3 rounded-full bg-[#7E2238] inline-block"></span>
                  <h3 className="font-semibold text-base text-[#4A101C]">Accurate Data Entry</h3>
                </div>
                <p className="text-sm text-[#5F4A50] leading-relaxed">
                  Double-checking every detail to ensure your applications are accepted on the first try.
                </p>
              </div>

              {/* Card 3 */}
              <div className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#E6D9CF] shadow-xs">
                <div className="flex items-center gap-3 mb-2.5">
                  <span className="w-3 h-3 rounded-full bg-[#7E2238] inline-block"></span>
                  <h3 className="font-semibold text-base text-[#4A101C]">Secure Records</h3>
                </div>
                <p className="text-sm text-[#5F4A50] leading-relaxed">
                  Your personal information and documents are handled with the utmost privacy and security.
                </p>
              </div>

              {/* Card 4 */}
              <div className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#E6D9CF] shadow-xs">
                <div className="flex items-center gap-3 mb-2.5">
                  <span className="w-3 h-3 rounded-full bg-[#7E2238] inline-block"></span>
                  <h3 className="font-semibold text-base text-[#4A101C]">Dedicated Support</h3>
                </div>
                <p className="text-sm text-[#5F4A50] leading-relaxed">
                  We are always just a phone call away to answer your questions and provide updates.
                </p>
              </div>
            </div>
          </div>

          {/* Right Column: Arch Handshake Visual */}
          <div className="lg:col-span-5 flex justify-center lg:justify-end">
            <div className="relative w-full max-w-[440px]">
              {/* Subtle outer outline */}
              <div className="absolute -inset-2.5 rounded-t-[190px] rounded-b-[36px] border border-[#DEC8C0]/80 pointer-events-none"></div>

              {/* Arch Frame */}
              <div className="relative rounded-t-[180px] rounded-b-[28px] overflow-hidden bg-[#ECE3DB] shadow-md border border-[#D9C4BB]/70 aspect-[4/4.4]">
                <img
                  src={handshakeImg}
                  alt="Professional handshake of trust and mutual agreement"
                  className="w-full h-full object-cover object-center transform hover:scale-[1.02] transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

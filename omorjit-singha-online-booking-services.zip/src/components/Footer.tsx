import React from 'react';
import { Phone, Mail, MapPin } from 'lucide-react';
import { SUPPORT_PHONE_DISPLAY, SUPPORT_PHONE_TEL } from '../utils/customerStorage';

interface FooterProps {
  onNavigate: (sectionId: string) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  return (
    <footer id="contact" className="bg-[#EFE7DE] border-t border-[#DDD1C6] pt-16 pb-12 text-[#4A383D]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-12 gap-10 lg:gap-14 pb-12 border-b border-[#D8C9BD]">
          {/* Col 1: Brand & Bio */}
          <div className="md:col-span-6 space-y-4">
            <div>
              <div className="font-serif-brand text-3xl font-semibold text-[#4A101C] leading-tight">
                Omorjit Singha
              </div>
              <div className="text-[11px] font-bold tracking-[0.22em] text-[#9E3E2F] uppercase mt-0.5">
                ONLINE BOOKING SERVICES
              </div>
            </div>

            <p className="text-sm text-[#5F4A50] max-w-md leading-relaxed">
              Your trusted partner for seamless travel bookings, passport services,
              and official documentation assistance.
            </p>

            <div className="pt-2 text-xs text-[#735A61] space-y-1.5">
              <div className="flex items-center gap-2">
                <MapPin className="w-3.5 h-3.5 text-[#7E2238]" />
                <span>Available for online consultations &amp; express support across India</span>
              </div>
              <div className="flex items-center gap-2">
                <Mail className="w-3.5 h-3.5 text-[#7E2238]" />
                <span>omorjitsingha305@gmail.com</span>
              </div>
            </div>
          </div>

          {/* Col 2: Explore Links */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] text-[#4A101C]">
              EXPLORE
            </h4>
            <ul className="space-y-2.5 text-sm text-[#5F4A50]">
              <li>
                <button
                  onClick={() => onNavigate('services')}
                  className="hover:text-[#7E2238] hover:underline cursor-pointer transition-colors"
                >
                  Our Services
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('about')}
                  className="hover:text-[#7E2238] hover:underline cursor-pointer transition-colors"
                >
                  About Us
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('booking')}
                  className="hover:text-[#7E2238] hover:underline cursor-pointer transition-colors"
                >
                  Book Now
                </button>
              </li>
              <li>
                <button
                  onClick={() => onNavigate('admin')}
                  className="hover:text-[#7E2238] hover:underline cursor-pointer transition-colors"
                >
                  Admin Dashboard
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Contact */}
          <div className="md:col-span-3 space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-[0.2em] text-[#4A101C]">
              CONTACT
            </h4>
            <div className="space-y-2 text-sm text-[#5F4A50]">
              <p>Call us anytime</p>
              <div className="pt-0.5">
                <span className="text-xs text-[#7B666C] block">Direct Support:</span>
                <a
                  href={SUPPORT_PHONE_TEL}
                  className="font-bold text-base text-[#4A101C] hover:text-[#7E2238] flex items-center gap-1.5 mt-0.5"
                >
                  <Phone className="w-4 h-4 text-[#7E2238]" />
                  <span>{SUPPORT_PHONE_DISPLAY}</span>
                </a>
              </div>
              <p className="text-xs text-[#7B666C] pt-1">
                Mon - Sun: 7:00 AM – 10:30 PM IST (Special Tatkal hours active from 8:00 AM)
              </p>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 flex flex-col sm:flex-row items-center justify-between text-xs text-[#7B666C] gap-3">
          <div>
            © 2026 Omorjit Singha Services. All rights reserved.
          </div>
          <div className="text-right">
            Designed for clarity and efficiency.
          </div>
        </div>
      </div>
    </footer>
  );
};

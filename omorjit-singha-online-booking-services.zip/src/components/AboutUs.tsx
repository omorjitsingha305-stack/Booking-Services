import React from 'react';
import aboutImg from '../assets/images/about_customer_service_1791215066792.jpg';

export const AboutUs: React.FC = () => {
  return (
    <section id="about" className="py-20 bg-[#F5EEE6]/70 border-y border-[#E9DED4] relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-14 items-center">
          {/* Left Column: Arch Image */}
          <div className="lg:col-span-5 order-2 lg:order-1 flex justify-center lg:justify-start">
            <div className="relative w-full max-w-[440px]">
              {/* Subtle outer outline */}
              <div className="absolute -inset-2.5 rounded-t-[190px] rounded-b-[36px] border border-[#DEC8C0]/80 pointer-events-none"></div>

              {/* Arch Frame */}
              <div className="relative rounded-t-[180px] rounded-b-[28px] overflow-hidden bg-[#ECE3DB] shadow-md border border-[#D9C4BB]/70 aspect-[4/4.4]">
                <img
                  src={aboutImg}
                  alt="Customer service specialist assisting customer with documentation"
                  className="w-full h-full object-cover object-center transform hover:scale-[1.02] transition-transform duration-500"
                  referrerPolicy="no-referrer"
                  loading="lazy"
                />
              </div>
            </div>
          </div>

          {/* Right Column: Copy & Highlights */}
          <div className="lg:col-span-7 order-1 lg:order-2 space-y-6 sm:space-y-8">
            <div className="flex items-center gap-3">
              <span className="w-8 h-[1.5px] bg-[#9D384E]"></span>
              <span className="text-[12px] sm:text-[13px] font-bold uppercase tracking-[0.2em] text-[#8C2D43]">
                ABOUT US
              </span>
            </div>

            <h2 className="font-serif-brand text-3xl sm:text-4xl lg:text-[50px] font-semibold text-[#4A101C] leading-[1.18] tracking-tight">
              Dedicated to simplifying your applications.
            </h2>

            <p className="text-base sm:text-lg text-[#5F4A50] leading-relaxed max-w-2xl font-normal">
              We take the hassle out of complex forms and bookings. With years of experience
              in travel reservations and official documentation, Omorjit Singha ensures your
              applications are processed smoothly and accurately.
            </p>

            {/* 01 and 02 Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 pt-3">
              <div className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#E6D9CF] shadow-xs">
                <span className="text-2xl font-serif font-bold text-[#7E2238] block mb-2">
                  01
                </span>
                <p className="text-sm sm:text-[15px] text-[#4F3C41] leading-relaxed font-medium">
                  Accurate form filling to prevent application rejections and delays.
                </p>
              </div>

              <div className="bg-[#FAF7F2] p-6 rounded-2xl border border-[#E6D9CF] shadow-xs">
                <span className="text-2xl font-serif font-bold text-[#7E2238] block mb-2">
                  02
                </span>
                <p className="text-sm sm:text-[15px] text-[#4F3C41] leading-relaxed font-medium">
                  Friendly, personalized support from inquiry to final confirmation.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

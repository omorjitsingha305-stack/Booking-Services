import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { CustomerRecord, BookingService, BookingStatus, AVAILABLE_SERVICES, STATUS_OPTIONS } from '../types/customer';
import { calculateAge } from '../utils/customerStorage';

interface CustomerModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (record: CustomerRecord) => void;
  initialRecord?: CustomerRecord | null;
}

export const CustomerModal: React.FC<CustomerModalProps> = ({
  isOpen,
  onClose,
  onSave,
  initialRecord,
}) => {
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [dateOfBirth, setDateOfBirth] = useState('');
  const [age, setAge] = useState<number | null>(null);
  const [service, setService] = useState<BookingService>('Railway Booking (AC / Non-AC / Tatkal)');
  const [status, setStatus] = useState<BookingStatus>('Pending');
  const [notes, setNotes] = useState('');
  const [errorMsg, setErrorMsg] = useState('');

  useEffect(() => {
    if (initialRecord) {
      setFullName(initialRecord.fullName);
      setPhoneNumber(initialRecord.phoneNumber);
      setDateOfBirth(initialRecord.dateOfBirth);
      setAge(initialRecord.age);
      setService(initialRecord.service);
      setStatus(initialRecord.status);
      setNotes(initialRecord.notes || '');
    } else {
      setFullName('');
      setPhoneNumber('');
      setDateOfBirth('');
      setAge(null);
      setService('Railway Booking (AC / Non-AC / Tatkal)');
      setStatus('Pending');
      setNotes('');
    }
    setErrorMsg('');
  }, [initialRecord, isOpen]);

  // Real-time automatic age calculation
  useEffect(() => {
    if (dateOfBirth) {
      const computed = calculateAge(dateOfBirth);
      setAge(computed);
    } else {
      setAge(null);
    }
  }, [dateOfBirth]);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!fullName.trim()) {
      setErrorMsg('Full name is required.');
      return;
    }
    if (!phoneNumber.trim()) {
      setErrorMsg('Phone number is required.');
      return;
    }
    if (!dateOfBirth) {
      setErrorMsg('Date of Birth is required.');
      return;
    }

    const calculatedAge = calculateAge(dateOfBirth) ?? 0;

    const recordToSave: CustomerRecord = {
      id: initialRecord ? initialRecord.id : `REC-${Date.now().toString().slice(-6)}`,
      fullName: fullName.trim(),
      phoneNumber: phoneNumber.trim(),
      dateOfBirth,
      age: calculatedAge,
      service,
      status,
      notes: notes.trim(),
      createdAt: initialRecord ? initialRecord.createdAt : new Date().toISOString(),
      updatedAt: initialRecord ? new Date().toISOString() : undefined,
    };

    onSave(recordToSave);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/45 backdrop-blur-xs animate-in fade-in duration-150">
      <div className="bg-[#FAF7F2] rounded-3xl max-w-lg w-full p-6 sm:p-8 border border-[#E5D8CE] shadow-2xl relative max-h-[92vh] overflow-y-auto">
        <div className="flex items-center justify-between pb-4 border-b border-[#E8DDD4] mb-6">
          <div>
            <h3 className="font-serif-brand text-2xl font-semibold text-[#4A101C]">
              {initialRecord ? 'Edit Customer Record' : 'Add New Customer'}
            </h3>
            <p className="text-xs text-[#7B666C] mt-0.5">
              {initialRecord ? `Updating reference ID: ${initialRecord.id}` : 'Create a new booking and customer profile'}
            </p>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-full text-[#6E4E55] hover:bg-[#F3EBE3] hover:text-[#4A101C] transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {errorMsg && (
          <div className="mb-4 p-3 rounded-xl bg-rose-50 border border-rose-200 text-rose-900 text-xs font-medium">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Full Name */}
          <div className="space-y-1">
            <label className="block text-[11px] font-bold tracking-wider uppercase text-[#5E474D]">
              Full Name
            </label>
            <input
              type="text"
              required
              value={fullName}
              onChange={(e) => setFullName(e.target.value)}
              placeholder="e.g. Rahul Sharma"
              className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#DAC7BE] text-[#4A101C] text-sm focus:outline-none focus:ring-2 focus:ring-[#B04A5A]"
            />
          </div>

          {/* Phone Number */}
          <div className="space-y-1">
            <label className="block text-[11px] font-bold tracking-wider uppercase text-[#5E474D]">
              Phone Number
            </label>
            <input
              type="tel"
              required
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="e.g. +91 98765 43210"
              className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#DAC7BE] text-[#4A101C] text-sm focus:outline-none focus:ring-2 focus:ring-[#B04A5A]"
            />
          </div>

          {/* Service Required */}
          <div className="space-y-1">
            <label className="block text-[11px] font-bold tracking-wider uppercase text-[#5E474D]">
              Service
            </label>
            <select
              value={service}
              onChange={(e) => setService(e.target.value as BookingService)}
              className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#DAC7BE] text-[#4A101C] text-sm focus:outline-none focus:ring-2 focus:ring-[#B04A5A]"
            >
              {AVAILABLE_SERVICES.map((s) => (
                <option key={s} value={s}>
                  {s}
                </option>
              ))}
            </select>
          </div>

          {/* DOB & Auto-calculated Age */}
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1">
              <label className="block text-[11px] font-bold tracking-wider uppercase text-[#5E474D]">
                Date of Birth
              </label>
              <input
                type="date"
                required
                max={new Date().toISOString().split('T')[0]}
                value={dateOfBirth}
                onChange={(e) => setDateOfBirth(e.target.value)}
                className="w-full px-3 py-2.5 rounded-xl bg-white border border-[#DAC7BE] text-[#4A101C] text-sm focus:outline-none focus:ring-2 focus:ring-[#B04A5A]"
              />
            </div>

            <div className="space-y-1">
              <label className="block text-[11px] font-bold tracking-wider uppercase text-[#5E474D]">
                Age (Auto-calculated)
              </label>
              <input
                type="text"
                readOnly
                value={age !== null ? `${age} yrs` : 'Auto'}
                className="w-full px-3 py-2.5 rounded-xl bg-[#EDE2DA] border border-[#DAC7BE] text-[#4A101C] font-semibold text-sm cursor-not-allowed"
              />
            </div>
          </div>

          {/* Status */}
          <div className="space-y-1">
            <label className="block text-[11px] font-bold tracking-wider uppercase text-[#5E474D]">
              Status
            </label>
            <select
              value={status}
              onChange={(e) => setStatus(e.target.value as BookingStatus)}
              className="w-full px-4 py-2.5 rounded-xl bg-white border border-[#DAC7BE] text-[#4A101C] text-sm focus:outline-none focus:ring-2 focus:ring-[#B04A5A]"
            >
              {STATUS_OPTIONS.map((st) => (
                <option key={st} value={st}>
                  {st}
                </option>
              ))}
            </select>
          </div>

          {/* Notes */}
          <div className="space-y-1">
            <label className="block text-[11px] font-bold tracking-wider uppercase text-[#5E474D]">
              Notes / Special Instructions
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="e.g. Journey details, Tatkal requirements, passport office location"
              className="w-full px-4 py-2 rounded-xl bg-white border border-[#DAC7BE] text-[#4A101C] text-sm focus:outline-none focus:ring-2 focus:ring-[#B04A5A] resize-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 rounded-xl border border-[#DAC7BE] text-[#5E474D] text-sm font-medium hover:bg-[#F5EDE5] transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-6 py-2.5 rounded-xl bg-[#7E2238] hover:bg-[#681628] text-white font-semibold text-sm transition-all shadow-sm"
            >
              {initialRecord ? 'Save Changes' : 'Add Record'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

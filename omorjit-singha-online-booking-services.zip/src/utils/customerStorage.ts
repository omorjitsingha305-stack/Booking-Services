import { CustomerRecord, BookingService, BookingStatus } from '../types/customer';

export const SUPPORT_PHONE_DISPLAY = '+91-7099626706';
export const SUPPORT_PHONE_TEL = 'tel:+917099626706';
export const BUSINESS_NAME = 'Omorjit Singha Online Booking Services';

const STORAGE_KEY = 'omorjit_singha_customers_v1';

export function calculateAge(dobString: string): number | null {
  if (!dobString) return null;
  const dob = new Date(dobString);
  if (isNaN(dob.getTime())) return null;

  const today = new Date();
  let age = today.getFullYear() - dob.getFullYear();
  const monthDiff = today.getMonth() - dob.getMonth();
  if (monthDiff < 0 || (monthDiff === 0 && today.getDate() < dob.getDate())) {
    age--;
  }
  return age >= 0 ? age : 0;
}

export function formatDateDisplay(dateString: string): string {
  if (!dateString) return '-';
  const parts = dateString.split('-');
  if (parts.length === 3) {
    const [year, month, day] = parts;
    return `${day}-${month}-${year}`;
  }
  const date = new Date(dateString);
  if (isNaN(date.getTime())) return dateString;
  const day = String(date.getDate()).padStart(2, '0');
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const year = date.getFullYear();
  return `${day}-${month}-${year}`;
}

const INITIAL_RECORDS: CustomerRecord[] = [
  {
    id: 'rec_101',
    fullName: 'Rahul Debbarma',
    phoneNumber: '+91 98621 44520',
    dateOfBirth: '1996-04-15',
    age: 30,
    service: 'Railway Booking (AC / Non-AC / Tatkal)',
    status: 'In Progress',
    notes: 'Tatkal booking for 3AC Rajdhani Express on 12th Oct',
    createdAt: '2026-10-01T09:30:00Z',
  },
  {
    id: 'rec_102',
    fullName: 'Priya Sharma',
    phoneNumber: '+91 87319 82310',
    dateOfBirth: '2001-08-22',
    age: 25,
    service: 'Passport Services (New Application)',
    status: 'Pending',
    notes: 'New passport application appointment & document verification',
    createdAt: '2026-10-02T14:15:00Z',
  },
  {
    id: 'rec_103',
    fullName: 'Bikramjit Nath',
    phoneNumber: '+91 70054 62198',
    dateOfBirth: '1992-11-05',
    age: 33,
    service: 'Driving License Assistance',
    status: 'Completed',
    notes: 'Learner license slot booked and test documentation verified',
    createdAt: '2026-09-28T11:00:00Z',
  },
  {
    id: 'rec_104',
    fullName: 'Ananya Roy',
    phoneNumber: '+91 94361 78902',
    dateOfBirth: '1999-01-30',
    age: 27,
    service: 'Job Application Help (Documentation & Form-filling)',
    status: 'In Progress',
    notes: 'State Civil Services examination portal form-filling & certificate upload',
    createdAt: '2026-10-03T16:45:00Z',
  },
  {
    id: 'rec_105',
    fullName: 'Debasish Singha',
    phoneNumber: '+91 98633 55120',
    dateOfBirth: '1988-06-18',
    age: 38,
    service: 'Flight Booking (Domestic & International)',
    status: 'Completed',
    notes: 'Round-trip flight booking to New Delhi',
    createdAt: '2026-09-25T10:10:00Z',
  },
];

export function getStoredCustomers(): CustomerRecord[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_RECORDS));
      return INITIAL_RECORDS;
    }
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : INITIAL_RECORDS;
  } catch (err) {
    console.error('Failed to parse customer records from localStorage:', err);
    return INITIAL_RECORDS;
  }
}

export function saveCustomers(records: CustomerRecord[]): void {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(records));
  } catch (err) {
    console.error('Failed to save customer records to localStorage:', err);
  }
}

export function resetToSampleCustomers(): CustomerRecord[] {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(INITIAL_RECORDS));
  return INITIAL_RECORDS;
}

export function clearAllCustomers(): CustomerRecord[] {
  const empty: CustomerRecord[] = [];
  localStorage.setItem(STORAGE_KEY, JSON.stringify(empty));
  return empty;
}

export function exportCustomersToCSV(records: CustomerRecord[]): void {
  const headers = ['ID', 'Full Name', 'Phone Number', 'Date of Birth', 'Age', 'Service', 'Status', 'Notes', 'Created At'];
  const rows = records.map((r) => [
    `"${r.id}"`,
    `"${r.fullName.replace(/"/g, '""')}"`,
    `"${r.phoneNumber}"`,
    `"${formatDateDisplay(r.dateOfBirth)}"`,
    r.age,
    `"${r.service.replace(/"/g, '""')}"`,
    `"${r.status}"`,
    `"${(r.notes || '').replace(/"/g, '""')}"`,
    `"${new Date(r.createdAt).toLocaleString()}"`,
  ]);

  const csvContent = [headers.join(','), ...rows.map((row) => row.join(','))].join('\n');
  const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.setAttribute('download', `customer_records_${new Date().toISOString().slice(0, 10)}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

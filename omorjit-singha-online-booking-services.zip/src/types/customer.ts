export type BookingService =
  | 'Railway Booking (AC / Non-AC / Tatkal)'
  | 'Flight Booking (Domestic & International)'
  | 'Bus Booking (Sleeper & Seater)'
  | 'Passport Services (New Application)'
  | 'Passport Services (Renewal Assistance)'
  | 'Driving License Assistance'
  | 'Job Application Help (Documentation & Form-filling)'
  | 'Official Portal Registration';

export type BookingStatus = 'Pending' | 'In Progress' | 'Completed' | 'Cancelled';

export interface CustomerRecord {
  id: string;
  fullName: string;
  phoneNumber: string;
  dateOfBirth: string; // YYYY-MM-DD
  age: number;
  service: BookingService;
  status: BookingStatus;
  notes?: string;
  createdAt: string; // ISO date
  updatedAt?: string;
}

export const AVAILABLE_SERVICES: BookingService[] = [
  'Railway Booking (AC / Non-AC / Tatkal)',
  'Flight Booking (Domestic & International)',
  'Bus Booking (Sleeper & Seater)',
  'Passport Services (New Application)',
  'Passport Services (Renewal Assistance)',
  'Driving License Assistance',
  'Job Application Help (Documentation & Form-filling)',
  'Official Portal Registration',
];

export const STATUS_OPTIONS: BookingStatus[] = [
  'Pending',
  'In Progress',
  'Completed',
  'Cancelled',
];
